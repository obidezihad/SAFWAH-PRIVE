# SAFWAH PRIVE' - System Architecture

## 1. Sitemap
- **/**: Homepage (Hero, Trending, Categories)
- **/shop**: Grid view with advanced sidebar filters
- **/product/:id**: High-contrast detail page with trust signals
- **/cart**: Item review and price summary
- **/checkout**: Multi-step flow optimized for bKash/Nagad/COD
- **/track-order**: Live tracking for Pathao/RedX integrations
- **/contact**: WhatsApp-first support channel

## 2. Database Schema (Firestore Collections)

### `products`
```typescript
{
  id: string,
  name: string,
  price: number,
  originalPrice: number,
  category: string,
  tags: string[], // e.g., ["Trending", "New Arrival"]
  images: string[],
  description: string,
  specs: Map<string, string>,
  inventory: {
    stock: number,
    wholesalerSource: string // for dropshipping sync
  },
  audit: {
    createdAt: timestamp,
    updatedAt: timestamp
  }
}
```

### `orders`
```typescript
{
  id: string,
  userId: string,
  items: Array<{productId, quantity, priceAtPurchase}>,
  total: number,
  payment: {
    method: "COD" | "bKash" | "Nagad",
    transactionId?: string,
    status: "pending" | "paid"
  },
  shipping: {
    address: string,
    district: "Dhaka" | "Chittagong" | "Rangpur" | "Other",
    courier: "Pathao" | "RedX" | "Steadfast"
  },
  status: "order_placed" | "processing" | "shipped" | "delivered"
}
```

### `suppliers`
```typescript
{
  id: string,
  name: string,
  contactEmail: string,
  apiEndpoint?: string,
  baseShippingFee: number,
  reliabilityScore: number, // 1-5
  isActive: boolean
}
```

### `products` (Updated)
```typescript
{
  id: string,
  supplierId: string, // Linking to suppliers
  name: string,
  basePrice: number, // Supplier cost
  privePrice: number, // Customer price
  originalPrice: number,
  category: string,
  variants: {
    sizesContent: string[],
    colorsContent: string[]
  },
  inventory: {
    stock: number,
    lastSync: timestamp
  }
}
```

## 2. Order Flow Diagram (The Payment Shield)

1. **Customer Checkout**: Customer places order (bKash/Nagad/COD).
2. **Payment Verification**: 
   - If Mobile Wallet: Admin verifies TrxID in Dashboard.
   - If COD: Order moves to "Verification Pending."
3. **Internal Approval**: Admin triggers "Supplier Fulfillment" after payment verification.
4. **Supplier Routing**: 
   - System splits order by `supplierId`.
   - Sends automated webhook/email to Supplier A and Supplier B.
5. **Profit Retention**: You pay Supplier (Base Cost + Shipping). You keep the Margin.
6. **Last Mile**: Supplier ships to Pathao/RedX hub -> Delivery to Dhaka/Chittagong/Rangpur.

## 3. Product Ingestion Strategy (Headless Scale)
- **Scraper Layer**: A Node.js microservice uses Puppeteer to crawl supplier URLs.
- **Enrichment**: AI (Gemini) cleans the title and converts technical specs into "Elite Lifestyle" descriptions.
- **Optimization**: Images are processed (resized & filtered) to maintain high-contrast "Darm Elite" style before being stored in CDN.
