import React, { useState } from 'react';
import { Navbar, Footer } from './components/Layout';
import { ProductCard, SocialProofPopup } from './components/ProductInterface';
import { CheckoutFlow } from './components/CheckoutFlow';
import { ProductDetails } from './components/ProductDetails';
import { StyleQuiz } from './components/StyleQuiz';
import { OrderTracking } from './components/OrderTracking';
import { MOCK_PRODUCTS } from './constants';
import { Product, CartItem } from './types';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Truck, CreditCard, ArrowRight, X, Trash2, ChevronRight, CheckCircle2, Sparkles, Zap, Heart, ShoppingBag } from 'lucide-react';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);

  React.useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2500);
    return () => clearTimeout(timer);
  }, []);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [view, setView] = useState<'home' | 'checkout' | 'success' | 'product' | 'quiz' | 'wishlist'>('home');

  const toggleWishlist = (product: Product) => {
    setWishlist(prev => {
      const exists = prev.find(p => p.id === product.id);
      if (exists) {
        return prev.filter(p => p.id !== product.id);
      }
      return [...prev, product];
    });
  };
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [recentCategory, setRecentCategory] = useState<string | null>(null);
  const [quizBundle, setQuizBundle] = useState<Product[] | null>(null);

  const addToCart = (product: Product, variant?: CartItem['selectedVariant']) => {
    setRecentCategory(product.category);
    setCart(prev => {
      const exists = prev.find(item => 
        item.id === product.id && 
        JSON.stringify(item.selectedVariant) === JSON.stringify(variant)
      );
      if (exists) {
        return prev.map(item => 
          (item.id === product.id && JSON.stringify(item.selectedVariant) === JSON.stringify(variant)) 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { ...product, quantity: 1, selectedVariant: variant }];
    });
    // Open cart drawer only if not in checkout
    if (view !== 'checkout') setIsCartOpen(true);
  };

  const removeFromCart = (id: string, variant?: any) => {
    setCart(prev => prev.filter(item => 
      !(item.id === id && JSON.stringify(item.selectedVariant) === JSON.stringify(variant))
    ));
  };

  const handleProductClick = (product: Product) => {
    setRecentCategory(product.category);
    setSelectedProduct(product);
    setView('product');
    window.scrollTo(0, 0);
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  if (view === 'checkout') {
    return (
      <CheckoutFlow 
        cart={cart} 
        total={cartTotal} 
        onBack={() => setView('home')} 
        onComplete={() => {
          setCart([]);
          setView('success');
        }}
      />
    );
  }

  if (view === 'success') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6 text-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="max-w-md w-full bg-white p-12 shadow-2xl border border-gray-100">
          <div className="w-20 h-20 bg-brand-emerald/10 text-brand-emerald rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 size={48} />
          </div>
          <h2 className="text-3xl font-bold text-brand-charcoal mb-4 tracking-tight">Order Confirmed</h2>
          <p className="text-gray-500 text-sm mb-8 leading-relaxed italic">
            Your elite selection is being prepared. You will receive a WhatsApp confirmation shortly.
          </p>
          <button 
            onClick={() => setView('home')}
            className="w-full bg-brand-charcoal text-brand-gold py-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald transition-colors"
          >
            Return to Collection
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans">
      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div 
            key="loader"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: "easeInOut" }}
            className="fixed inset-0 z-[200] bg-brand-charcoal flex flex-col items-center justify-center"
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: [0, 1, 1, 0], scale: [0.9, 1, 1, 0.9] }}
              transition={{ duration: 2.5, times: [0, 0.2, 0.8, 1], repeat: Infinity }}
              className="flex flex-col items-center gap-6"
            >
              <div className="relative w-24 h-24">
                <svg viewBox="0 0 100 100" className="w-full h-full fill-brand-gold">
                  <path d="M50 0 L61 35 L98 35 L68 57 L79 91 L50 70 L21 91 L32 57 L2 35 L39 35 Z" />
                </svg>
              </div>
              <div className="flex flex-col items-center">
                <h2 className="text-3xl font-serif font-black tracking-[0.3em] text-white">SAFWAH</h2>
                <h3 className="text-brand-gold font-serif tracking-[0.5em] text-sm -mt-1 underline decoration-brand-emerald underline-offset-8">PRIVE'</h3>
              </div>
              <p className="text-gray-600 text-[10px] uppercase tracking-[0.4em] mt-8">The Standard of Trust</p>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <Navbar 
        cartCount={cart.reduce((s, i) => s + i.quantity, 0)} 
        wishlistCount={wishlist.length}
        onCartClick={() => setIsCartOpen(true)} 
        onWishlistClick={() => setView('wishlist')}
      />
      
      <main>
        {view === 'quiz' ? (
          <StyleQuiz 
            onBack={() => setView('home')} 
            onComplete={(bundle) => {
              setQuizBundle(bundle);
              setView('home');
            }}
          />
        ) : view === 'wishlist' ? (
          <section className="py-24 min-h-[60vh] container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-baseline justify-between mb-16 gap-4">
              <div>
                <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-2 block italic underline underline-offset-4 decoration-brand-emerald">Your Private Selection</span>
                <h2 className="text-3xl md:text-5xl font-bold text-brand-charcoal tracking-tight">Wishlist</h2>
              </div>
              <button 
                onClick={() => setView('home')}
                className="text-xs font-bold uppercase tracking-widest text-gray-500 hover:text-brand-charcoal transition-colors flex items-center gap-2"
              >
                <ArrowRight size={16} className="rotate-180" /> Back to Collection
              </button>
            </div>

            {wishlist.length === 0 ? (
              <div className="text-center py-32 space-y-8 bg-gray-50 border border-dashed border-gray-200">
                <div className="inline-block p-8 bg-white rounded-full text-gray-200">
                  <Heart size={64} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-brand-charcoal uppercase tracking-widest">Your wishlist is empty</h3>
                  <p className="text-gray-500 text-sm max-w-xs mx-auto">Save items you love and they will appear here for your future elite checkout.</p>
                </div>
                <button 
                  onClick={() => setView('home')}
                  className="bg-brand-charcoal text-brand-gold px-10 py-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald transition-colors"
                >
                  Start Discovery
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
                {wishlist.map(product => (
                  <div key={product.id} onClick={() => handleProductClick(product)} className="cursor-pointer">
                    <ProductCard 
                      product={product} 
                      isWishlisted={true}
                      onAddToCart={(p) => addToCart(p)} 
                      onToggleWishlist={toggleWishlist}
                    />
                  </div>
                ))}
              </div>
            )}
          </section>
        ) : view === 'product' && selectedProduct ? (
          <ProductDetails 
            product={selectedProduct} 
            isWishlisted={wishlist.some(p => p.id === selectedProduct.id)}
            onBack={() => setView('home')} 
            onAddToCart={addToCart} 
            onToggleWishlist={toggleWishlist}
          />
        ) : (
          <>
            {/* Hero Section */}
        <section className="relative h-[85vh] flex items-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2000&auto=format&fit=crop" 
              className="w-full h-full object-cover"
              alt="Luxury Banner"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-brand-charcoal/90 via-brand-charcoal/40 to-transparent" />
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-xl text-white"
            >
              <span className="text-brand-gold uppercase tracking-[0.4em] text-xs font-bold mb-4 block">Dhaka Exclusive</span>
              <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight tracking-tight">
                Curated Luxury for the <span className="italic text-brand-gold">Modern Elite</span>
              </h1>
              <p className="text-gray-300 text-lg mb-8 max-w-md leading-relaxed">
                SAFWAH PRIVE' brings international aesthetic trends directly to your door in Bangladesh. No custom hassle, just pure quality.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-brand-emerald text-white px-8 py-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-gold hover:text-brand-charcoal transition-all flex items-center justify-center gap-2">
                  Shop Trending BD <ArrowRight size={16} />
                </button>
                <button 
                  onClick={() => setView('quiz')}
                  className="bg-brand-gold/10 border border-brand-gold/30 text-brand-gold px-8 py-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-gold hover:text-brand-charcoal transition-all flex items-center justify-center gap-2"
                >
                  <Sparkles size={16} /> Signature Style Quiz
                </button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Global Trust Badges */}
        <section className="py-8 bg-brand-charcoal border-y border-white/5">
          <div className="container mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { icon: <ShieldCheck className="text-brand-gold" />, title: "Quality Inspected", desc: "Before every delivery" },
              { icon: <Truck className="text-brand-gold" />, title: "BD-Wide Logistics", desc: "Pathao & RedX Priority" },
              { icon: <ChevronRight className="text-brand-gold" />, title: "Pay on Delivery", desc: "COD in all major cities" },
              { icon: <CreditCard className="text-brand-gold" />, title: "Secure Payments", desc: "bKash & Nagad verified" },
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-4 group">
                <div className="p-3 bg-white/5 rounded-full group-hover:bg-brand-gold/20 transition-colors">
                  {feature.icon}
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold tracking-widest uppercase">{feature.title}</h4>
                  <p className="text-gray-500 text-[10px] uppercase">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Personalized Trending Section */}
        <section className="py-24 container mx-auto px-4" id="trending">
          <div className="flex flex-col md:flex-row items-baseline justify-between mb-16 gap-4">
            <div>
              <span className="text-brand-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-2 block italic underline underline-offset-4 decoration-brand-emerald">
                {recentCategory ? `Personalized for you in ${recentCategory}` : 'Bestsellers Dhaka'}
              </span>
              <h2 className="text-3xl md:text-5xl font-bold text-brand-charcoal tracking-tight">
                {recentCategory ? 'Your Style Selection' : 'Trending in BD'}
              </h2>
            </div>
            <a href="#" className="group text-xs font-bold uppercase tracking-widest text-brand-charcoal flex items-center gap-2 hover:text-brand-gold transition-colors">
              View All Collection <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
            {MOCK_PRODUCTS
              .sort((a, b) => {
                if (a.category === recentCategory && b.category !== recentCategory) return -1;
                if (b.category === recentCategory && a.category !== recentCategory) return 1;
                return 0;
              })
              .map(product => (
                <div key={product.id} onClick={() => handleProductClick(product)} className="cursor-pointer">
                  <ProductCard 
                    product={product} 
                    isWishlisted={wishlist.some(p => p.id === product.id)}
                    onAddToCart={(p) => addToCart(p)} 
                    onToggleWishlist={toggleWishlist}
                  />
                </div>
              ))}
          </div>
        </section>

        {quizBundle && (
          <section className="py-24 bg-brand-charcoal text-white overflow-hidden relative border-y border-brand-gold/20">
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/5 rounded-full blur-[100px] -mr-32 -mt-32"></div>
            <div className="container mx-auto px-4 relative z-10">
              <div className="mb-16 text-center space-y-4">
                <span className="text-brand-gold text-xs font-bold uppercase tracking-[0.3em]">AI Selection</span>
                <h2 className="text-4xl md:text-6xl font-bold italic tracking-tight">YOUR SIGNATURE BUNDLE</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                <div className="space-y-8">
                  <p className="text-xl text-gray-300 font-light border-l-4 border-brand-gold pl-8 leading-relaxed">
                    Our intelligence layer has matched your preferences with current global trends. This bundle represents the <span className="text-brand-gold font-bold italic">Safwah Standard</span> specifically for you.
                  </p>
                  <div className="flex gap-4">
                    <button className="bg-brand-gold text-brand-charcoal px-10 py-5 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald hover:text-white transition-all shadow-xl shadow-brand-gold/10">Buy Elite Bundle</button>
                    <button onClick={() => setQuizBundle(null)} className="text-white border border-white/20 px-10 py-5 text-xs font-bold uppercase tracking-widest hover:border-brand-gold transition-all">Retake Quiz</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  {quizBundle.map(p => (
                    <motion.div 
                      key={p.id} 
                      onClick={() => handleProductClick(p)}
                      className="bg-white/5 p-6 rounded border border-white/10 group cursor-pointer relative"
                    >
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleWishlist(p);
                        }}
                        className={`absolute top-4 right-4 z-10 p-2 rounded-full backdrop-blur-md transition-colors ${wishlist.some(item => item.id === p.id) ? 'bg-brand-gold text-brand-charcoal' : 'bg-white/10 text-white hover:bg-brand-gold hover:text-brand-charcoal'}`}
                      >
                        <Heart size={14} fill={wishlist.some(item => item.id === p.id) ? 'currentColor' : 'none'} />
                      </button>
                      <img src={p.image} className="aspect-square object-cover mb-4 grayscale group-hover:grayscale-0 transition-all duration-700" alt={p.name} />
                      <p className="text-[10px] font-bold uppercase tracking-widest mb-1 text-white/50">{p.category}</p>
                      <p className="text-sm font-bold uppercase tracking-widest mb-2 truncate">{p.name}</p>
                      <p className="text-brand-gold font-bold italic">৳{p.price}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Featured Lifestyle Section */}
        <section className="bg-gray-50 py-24">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative aspect-square overflow-hidden bg-brand-emerald">
                <img 
                  src="https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=1200" 
                  alt="Leather Collection"
                  className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white/10 backdrop-blur-xl p-12 border border-white/20 text-center max-w-sm">
                    <span className="text-brand-gold text-xs font-bold uppercase tracking-[0.5em] mb-4 block">Handcrafted</span>
                    <h3 className="text-white text-4xl font-bold mb-6 italic">The Signature Leather Series</h3>
                    <button className="bg-white text-brand-charcoal px-8 py-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald hover:text-white transition-all">
                      Explore Series
                    </button>
                  </div>
                </div>
              </div>
              <div className="space-y-8 lg:pl-12">
                <span className="text-brand-emerald font-bold uppercase tracking-widest text-sm">— High Performance Lifestyle</span>
                <h2 className="text-4xl md:text-6xl font-bold text-brand-charcoal leading-tight">Elite Essentials for <span className="text-brand-gold">Modern Living</span></h2>
                <p className="text-gray-600 leading-relaxed text-lg italic">
                  "At SAFWAH PRIVE', we believe luxury isn't just a price tag—it's a selection process. Every item in our tech and lifestyle catalog is vetted for the premium Bangladeshi consumer."
                </p>
                <div className="grid grid-cols-2 gap-8 pt-4">
                  <div>
                    <span className="text-3xl font-bold text-brand-emerald italic">12k+</span>
                    <p className="text-gray-500 text-xs uppercase tracking-widest mt-1">Happy Customers in BD</p>
                  </div>
                  <div>
                    <span className="text-3xl font-bold text-brand-emerald italic">24h</span>
                    <p className="text-gray-500 text-xs uppercase tracking-widest mt-1">Processing Fast-Sync</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
          </>
        )}
        {/* Tracking & Community */}
        <section className="py-24 container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <OrderTracking />
            
            <div className="space-y-12">
              <div className="space-y-4">
                <span className="text-brand-emerald text-xs font-bold uppercase tracking-[0.3em]">— Elite Community</span>
                <h2 className="text-4xl md:text-5xl font-bold text-brand-charcoal tracking-tight">Social <span className="text-brand-gold italic">Proof</span></h2>
                <p className="text-gray-500 text-sm leading-relaxed uppercase tracking-widest">
                  Unboxing experiences shared by our Prive' members. Join the movement on TikTok/Instagram.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { user: "@zahid_bd", img: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=400" },
                  { user: "@rifat_styles", img: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=400" }
                ].map((video, i) => (
                  <div key={i} className="relative aspect-[9/16] bg-gray-100 group overflow-hidden">
                    <img src={video.img} className="w-full h-full object-cover grayscale brightness-75 group-hover:grayscale-0 transition-all duration-700" alt="Review" />
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                       <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/30">
                         <Zap size={20} fill="white" />
                       </div>
                    </div>
                    <div className="absolute bottom-4 left-4">
                      <p className="text-white text-[10px] font-bold tracking-widest uppercase">{video.user}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <SocialProofPopup />

      {/* Cart Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100]" 
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white z-[101] shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h2 className="text-xl font-bold tracking-tight text-brand-charcoal">Your Selection</h2>
                <button onClick={() => setIsCartOpen(false)} className="text-gray-400 hover:text-brand-charcoal transition-colors">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <div className="p-6 bg-gray-50 rounded-full mb-4">
                      <ShoppingBag size={48} className="text-gray-200" />
                    </div>
                    <p className="text-gray-500 font-medium italic">Your bag is as empty as a dusty vault.</p>
                    <button 
                      onClick={() => setIsCartOpen(false)}
                      className="mt-6 text-brand-emerald font-bold uppercase tracking-widest text-xs underline underline-offset-4"
                    >
                      Continue Curating
                    </button>
                  </div>
                ) : (
                  cart.map((item, idx) => (
                    <div key={`${item.id}-${idx}-${JSON.stringify(item.selectedVariant)}`} className="flex gap-4 group">
                      <div className="h-24 w-20 bg-gray-100 flex-shrink-0 overflow-hidden">
                        <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="text-sm font-bold text-brand-charcoal line-clamp-1">{item.name}</h4>
                          <button onClick={() => removeFromCart(item.id, item.selectedVariant)} className="text-gray-300 hover:text-red-500 transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                        {item.selectedVariant && (
                          <p className="text-[9px] text-brand-gold font-bold uppercase tracking-widest mb-1 italic">
                            {item.selectedVariant.size} {item.selectedVariant.color && `/ ${item.selectedVariant.color}`} {item.selectedVariant.material && `/ ${item.selectedVariant.material}`}
                          </p>
                        )}
                        <p className="text-[10px] text-gray-500 uppercase mb-2">QTY: {item.quantity}</p>
                        <p className="text-brand-emerald font-bold italic">৳{item.price * item.quantity}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-gray-100 bg-gray-50">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-xs font-bold uppercase tracking-widest text-gray-500">Total Selection Value</span>
                    <span className="text-2xl font-bold text-brand-charcoal italic">৳{cartTotal}</span>
                  </div>
                  <button 
                    onClick={() => {
                      setIsCartOpen(false);
                      setView('checkout');
                    }}
                    className="w-full bg-brand-charcoal text-brand-gold py-4 px-6 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald transition-colors flex items-center justify-center gap-2"
                  >
                    Proceed to Elite Checkout <ArrowRight size={16}/>
                  </button>
                  <p className="mt-4 text-[10px] text-center text-gray-400 font-medium">
                    Shipping calculated at checkout. Pathao & RedX delivery available.
                  </p>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
