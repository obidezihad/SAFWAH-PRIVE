import React, { useState } from 'react';
import { ShieldCheck, Truck, CreditCard, ChevronRight, CheckCircle2, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { CartItem } from '../types';

interface CheckoutFlowProps {
  cart: CartItem[];
  total: number;
  onBack: () => void;
  onComplete: () => void;
}

export const CheckoutFlow: React.FC<CheckoutFlowProps> = ({ cart, total, onBack, onComplete }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'bKash' | 'Nagad' | 'Hybrid'>('COD');
  const [district, setDistrict] = useState<string>('');
  const [transactionId, setTransactionId] = useState<string>('');

  const shippingFee = district === 'Dhaka' ? 80 : district ? 150 : 0;
  const depositAmount = paymentMethod === 'Hybrid' ? 500 : 0;
  const finalTotal = total + shippingFee;
  const codDueAmount = finalTotal - depositAmount;

  const districts = ['Dhaka', 'Chittagong', 'Rangpur', 'Sylhet', 'Rajshahi', 'Khulna', 'Barishal', 'Mymensingh'];

  return (
    <div className="bg-white min-h-screen pb-20">
      <div className="container mx-auto px-4 max-w-4xl pt-8">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-brand-charcoal mb-8 text-xs font-bold uppercase tracking-widest">
          <ArrowLeft size={16} /> Back to Bag
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Form Side */}
          <div className="space-y-8">
            <div className="flex items-center gap-4 mb-8">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${step >= 1 ? 'bg-brand-emerald text-white' : 'bg-gray-100 text-gray-400'}`}>1</div>
              <div className="h-[1px] flex-1 bg-gray-100"></div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${step >= 2 ? 'bg-brand-emerald text-white' : 'bg-gray-100 text-gray-400'}`}>2</div>
            </div>

            {step === 1 ? (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <h2 className="text-2xl font-bold tracking-tight text-brand-charcoal">Shipping Logistics</h2>
                <div className="grid grid-cols-1 gap-4">
                  <input type="text" placeholder="Full Name (As per NID/Social)" className="w-full p-4 bg-gray-50 border-none text-sm focus:ring-2 focus:ring-brand-gold outline-none" />
                  <input type="tel" placeholder="Mobile Number (bKash linked preferred)" className="w-full p-4 bg-gray-50 border-none text-sm focus:ring-2 focus:ring-brand-gold outline-none" />
                  <textarea placeholder="Detailed Address (House, Road, Area)" rows={3} className="w-full p-4 bg-gray-50 border-none text-sm focus:ring-2 focus:ring-brand-gold outline-none"></textarea>
                  <select 
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full p-4 bg-gray-50 border-none text-sm focus:ring-2 focus:ring-brand-gold outline-none"
                  >
                    <option value="">Select District</option>
                    {districts.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <button 
                  onClick={() => setStep(2)}
                  className="w-full bg-brand-charcoal text-brand-gold py-4 font-bold uppercase tracking-[0.2em] text-xs hover:bg-brand-emerald transition-colors"
                >
                  Continue to Payment
                </button>
              </motion.div>
            ) : (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <h2 className="text-2xl font-bold tracking-tight text-brand-charcoal">Secure Settlement</h2>
                <div className="space-y-4">
                  {[
                    { id: 'COD', name: 'Standard COD', desc: 'Pay full on delivery', icon: <Truck size={20}/> },
                    { id: 'Hybrid', name: 'Elite Hybrid', desc: '৳500 Deposit + Rest COD', icon: <div className="font-bold text-brand-gold italic">Safe-Pay</div> },
                    { id: 'bKash', name: 'bKash Fast-Pay', desc: 'Secure mobile checkout', icon: <div className="font-bold text-pink-500">bkash</div> },
                    { id: 'Nagad', name: 'Nagad Secure', desc: 'Government verified wallet', icon: <div className="font-bold text-orange-500">Nagad</div> }
                  ].map((method) => (
                    <div key={method.id} className="space-y-4">
                      <label 
                        className={`flex items-center justify-between p-6 border transition-all cursor-pointer ${paymentMethod === method.id ? 'border-brand-emerald bg-brand-emerald/5' : 'border-gray-100'}`}
                      >
                        <div className="flex gap-4 items-center">
                          <input 
                            type="radio" 
                            name="payment" 
                            checked={paymentMethod === method.id} 
                            onChange={() => setPaymentMethod(method.id as any)}
                            className="accent-brand-emerald"
                          />
                          <div>
                            <p className="text-sm font-bold text-brand-charcoal uppercase tracking-widest">{method.name}</p>
                            <p className="text-[10px] text-gray-500 uppercase">{method.desc}</p>
                          </div>
                        </div>
                        {method.icon}
                      </label>
                      
                      {paymentMethod === method.id && method.id !== 'COD' && (
                        <motion.div 
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="px-6 pb-6 pt-2 space-y-4"
                        >
                          <div className="p-4 bg-pink-50 border border-pink-100 rounded text-[10px] text-pink-700 uppercase tracking-wider font-medium">
                            {method.id === 'Hybrid' ? 'Pay ৳500 Deposit to:' : 'Please send money to:'} <span className="font-bold underline text-xs">017XXXXXXXX</span> then enter the TrxID below.
                          </div>
                          <input 
                            type="text" 
                            placeholder="Transaction ID (TrxID)"
                            value={transactionId}
                            onChange={(e) => setTransactionId(e.target.value)}
                            className="w-full p-4 bg-gray-50 border-none text-sm focus:ring-2 focus:ring-brand-gold outline-none"
                          />
                        </motion.div>
                      )}
                    </div>
                  ))}
                </div>
                
                <div className="p-6 bg-brand-emerald/10 border border-brand-emerald/20 flex gap-4 items-start">
                  <ShieldCheck className="text-brand-emerald flex-shrink-0" />
                  <p className="text-[10px] text-brand-emerald font-medium leading-relaxed uppercase tracking-widest">
                    Your transaction is secured with 256-bit encryption. SAFWAH PRIVE' never stores your wallet pins.
                  </p>
                </div>

                <div className="flex gap-4">
                  <button onClick={() => setStep(1)} className="flex-1 border border-gray-200 py-4 text-xs font-bold uppercase tracking-widest hover:border-brand-charcoal transition-colors">
                    Back
                  </button>
                  <button 
                    onClick={onComplete}
                    className="flex-[2] bg-brand-charcoal text-brand-gold py-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald transition-colors"
                  >
                    Confirm Order
                  </button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Summary Side */}
          <div className="bg-gray-50 p-8 h-fit lg:sticky lg:top-32 border border-gray-100">
            <h3 className="text-xs font-bold uppercase tracking-widest text-brand-gold mb-8 italic underline underline-offset-8">Order Recap</h3>
            <div className="space-y-6 mb-8 max-h-[300px] overflow-y-auto pr-2">
              {cart.map(item => (
                <div key={item.id} className="flex gap-4 items-center">
                  <img src={item.image} className="w-16 h-16 object-cover bg-white p-1" alt={item.name} />
                  <div className="flex-1">
                    <p className="text-xs font-bold text-brand-charcoal">{item.name}</p>
                    <p className="text-[10px] text-gray-500">QTY: {item.quantity}</p>
                  </div>
                  <p className="text-xs font-bold italic">৳{item.price * item.quantity}</p>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-200 pt-6 space-y-4">
              <div className="flex justify-between text-xs text-gray-500 uppercase tracking-widest">
                <span>Selection Total</span>
                <span>৳{total}</span>
              </div>
              <div className="flex justify-between text-xs text-gray-500 uppercase tracking-widest">
                <span>Shipping ({district === 'Dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})</span>
                <span className={shippingFee === 0 ? "text-brand-emerald italic" : "text-brand-charcoal font-bold"}>
                  {shippingFee === 0 ? "SELECT DISTRICT" : `৳${shippingFee}`}
                </span>
              </div>
              <div className="h-[1px] bg-gray-200 my-4"></div>
              <div className="flex justify-between items-baseline">
                <span className="text-sm font-bold uppercase tracking-[0.2em] text-brand-charcoal">Final Settlement</span>
                <span className="text-3xl font-bold text-brand-emerald italic">৳{finalTotal}</span>
              </div>
              
              {paymentMethod === 'Hybrid' && (
                <div className="mt-4 pt-4 border-t border-dashed border-gray-200 space-y-2">
                  <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-brand-gold">
                    <span>Elite Deposit paid</span>
                    <span>-৳{depositAmount}</span>
                  </div>
                  <div className="flex justify-between text-xs font-black uppercase tracking-[0.2em] text-brand-charcoal bg-gray-50 p-2">
                    <span>Due on Delivery</span>
                    <span>৳{codDueAmount}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
