import React from 'react';
import { Menu, Search, ShoppingBag, User, Phone, Instagram, Facebook, X, ChevronRight, Camera, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

export const Navbar: React.FC<{ cartCount: number, wishlistCount: number, onCartClick: () => void, onWishlistClick: () => void }> = ({ cartCount, wishlistCount, onCartClick, onWishlistClick }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <button 
            onClick={() => setIsMenuOpen(true)}
            className="lg:hidden text-brand-charcoal" 
            id="mobile-menu-trigger"
          >
            <Menu size={24} />
          </button>
          
          <div className="hidden lg:flex items-center gap-6">
            {['Lifestyle', 'Tech', 'Fashion', 'Home Decor'].map((cat) => (
              <a 
                key={cat} 
                href={`#${cat.toLowerCase()}`}
                className="text-xs font-medium uppercase tracking-[0.2em] text-brand-charcoal hover:text-brand-gold transition-colors"
              >
                {cat}
              </a>
            ))}
          </div>
        </div>

        <a href="/" className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="relative w-8 h-8 md:w-10 md:h-10">
              <svg viewBox="0 0 100 100" className="w-full h-full fill-brand-gold">
                <path d="M50 0 L61 35 L98 35 L68 57 L79 91 L50 70 L21 91 L32 57 L2 35 L39 35 Z" />
              </svg>
            </div>
            <div className="flex flex-col md:flex-row md:items-baseline md:gap-2">
              <span className="text-lg md:text-2xl font-serif font-black tracking-[0.2em] text-brand-emerald leading-tight">SAFWAH</span>
              <span className="text-lg md:text-2xl font-serif font-black tracking-[0.2em] text-brand-gold leading-tight">PRIVE'</span>
            </div>
          </div>
        </a>

        <div className="flex items-center gap-6">
          <div className="hidden sm:flex items-center gap-4 relative group">
            <button className="text-brand-charcoal hover:text-brand-gold transition-colors">
              <Search size={22} />
            </button>
            <button className="text-brand-charcoal hover:text-brand-gold transition-colors border-l pl-4 border-gray-100 flex items-center gap-2">
              <Camera size={20} />
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold opacity-0 group-hover:opacity-100 transition-opacity">AI Lens</span>
            </button>
          </div>
          <button className="hidden sm:block text-brand-charcoal hover:text-brand-gold transition-colors">
            <User size={22} />
          </button>
          <button 
            onClick={onWishlistClick}
            className="group relative text-brand-charcoal hover:text-brand-gold transition-colors"
          >
            <Heart size={22} />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-gold text-brand-charcoal text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-bold">
                {wishlistCount}
              </span>
            )}
          </button>
          <button 
            onClick={onCartClick}
            className="group relative text-brand-charcoal hover:text-brand-gold transition-colors"
          >
            <ShoppingBag size={22} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-emerald text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      <motion.nav 
        initial={{ x: '-100%' }}
        animate={{ x: isMenuOpen ? 0 : '-100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="fixed inset-y-0 left-0 w-full max-w-xs bg-brand-charcoal z-[102] p-8 lg:hidden"
      >
        <div className="flex justify-between items-center mb-16">
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 100 100" className="w-6 h-6 fill-brand-gold">
              <path d="M50 0 L61 35 L98 35 L68 57 L79 91 L50 70 L21 91 L32 57 L2 35 L39 35 Z" />
            </svg>
            <span className="text-xl font-serif font-black tracking-widest text-white">SAFWAH <span className="text-brand-gold">PRIVE'</span></span>
          </div>
          <button onClick={() => setIsMenuOpen(false)} className="text-white">
            <X size={24} />
          </button>
        </div>
        
        <ul className="space-y-8">
          {['Lifestyle', 'Tech', 'Fashion', 'Home Decor', 'Trending in BD'].map((cat) => (
            <li key={cat}>
              <a 
                href={`#${cat.toLowerCase().replace(/ /g, '-')}`}
                onClick={() => setIsMenuOpen(false)}
                className="text-lg font-medium text-white hover:text-brand-gold flex items-center justify-between group"
              >
                {cat}
                <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </li>
          ))}
        </ul>

        <div className="absolute bottom-12 left-8 border-l border-brand-gold pl-4">
          <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2">Member Support</p>
          <p className="text-white text-sm">017XXXXXXXX</p>
          <p className="text-brand-gold text-[10px] uppercase font-bold mt-1">Available 10AM - 10PM</p>
        </div>
      </motion.nav>
    </header>
  );
};

export const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-charcoal py-16 text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <svg viewBox="0 0 100 100" className="w-8 h-8 fill-brand-gold">
                <path d="M50 0 L61 35 L98 35 L68 57 L79 91 L50 70 L21 91 L32 57 L2 35 L39 35 Z" />
              </svg>
              <span className="text-2xl font-serif font-black tracking-[0.2em] text-white">SAFWAH <span className="text-brand-gold">PRIVE'</span></span>
            </div>
            <p className="text-gray-400 text-sm max-w-sm leading-relaxed mb-6">
              The premier destination for the aesthetic elite of Bangladesh. Hand-picked dropshipping treasures curated for your luxury lifestyle.
            </p>
            <div className="flex gap-4">
              <a href="#" className="p-2 border border-gray-700 hover:border-brand-gold hover:text-brand-gold transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="p-2 border border-gray-700 hover:border-brand-gold hover:text-brand-gold transition-colors">
                <Facebook size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-brand-gold text-xs font-bold uppercase tracking-widest mb-6 underline underline-offset-8">Information</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Shipping to BD Districts</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Pathao Live Tracking</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Wholesale Inquiry</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-brand-gold text-xs font-bold uppercase tracking-widest mb-6 underline underline-offset-8">Support</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Track My Parcel</a></li>
              <li><a href="#" className="hover:text-white transition-colors underline decoration-brand-emerald underline-offset-4">COD Instructions</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-gray-500 uppercase tracking-widest">
          <p>© 2024 SAFWAH PRIVE'. All rights reserved in Dhaka, BD.</p>
          <div className="flex gap-4">
            <span>bKash Secure</span>
            <span>Nagad Verified</span>
            <span>Pathao Delivery</span>
          </div>
        </div>
      </div>
      
      {/* WhatsApp Floating Button */}
      <a 
        href="https://wa.me/8801234567890" 
        target="_blank" 
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center gap-2 group"
      >
        <Phone size={24} />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 text-sm font-medium">Chat Support</span>
      </a>
    </footer>
  );
};
