import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Package, Truck, CheckCircle2, ChevronRight, MapPin, Clock } from 'lucide-react';

interface TrackingState {
  orderId: string;
  status: 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered';
  location: string;
  lastUpdate: string;
  items: { name: string, quantity: number, supplier: string }[];
}

export const OrderTracking: React.FC = () => {
  const [orderId, setOrderId] = useState('');
  const [trackingData, setTrackingData] = useState<TrackingState | null>(null);

  const handleTrack = () => {
    // Mock Unified tracking logic (Combining multiple suppliers)
    if (orderId) {
      setTrackingData({
        orderId: orderId,
        status: 'Shipped',
        location: 'Dhaka Sorting Hub',
        lastUpdate: '2 hours ago',
        items: [
          { name: 'Elite Silk Panjabi', quantity: 1, supplier: 'Safwah Global' },
          { name: 'Phantom X1 Mech Keyboard', quantity: 1, supplier: 'Vault Tech' }
        ]
      });
    }
  };

  return (
    <div className="bg-white p-8 border border-gray-100 space-y-8">
      <div className="space-y-2">
        <h3 className="text-xl font-bold text-brand-charcoal uppercase tracking-widest">Unified Prive' Tracking</h3>
        <p className="text-[10px] text-gray-500 uppercase tracking-widest leading-relaxed">
          One journey, regardless of supplier origin. Enter your order ID from SMS.
        </p>
      </div>

      <div className="flex gap-2">
        <input 
          type="text" 
          placeholder="e.g., SP-XXXX-BD"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          className="flex-1 p-4 bg-gray-50 border-none text-sm focus:ring-2 focus:ring-brand-gold outline-none"
        />
        <button 
          onClick={handleTrack}
          className="bg-brand-charcoal text-brand-gold px-8 py-4 text-[10px] font-bold uppercase tracking-widest hover:bg-brand-emerald hover:text-white transition-all"
        >
          Locate
        </button>
      </div>

      {trackingData && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="space-y-8 pt-8 border-t border-gray-100"
        >
          <div className="flex justify-between items-center bg-brand-charcoal p-6 text-white rounded">
            <div>
               <p className="text-[10px] text-brand-gold font-bold uppercase tracking-[0.2em] mb-1">Status</p>
               <h4 className="text-xl font-bold italic">{trackingData.status}</h4>
            </div>
            <Package size={32} className="text-brand-gold opacity-50" />
          </div>

          <div className="space-y-6 relative">
            <div className="absolute left-[20px] top-4 bottom-4 w-[1px] bg-gray-200"></div>
            
            {[
              { label: 'Order Received', date: 'Yesterday, 10:00 AM', active: true },
              { label: 'Quality Vetted', date: 'Yesterday, 04:00 PM', active: true },
              { label: 'Shipped from Hub', date: trackingData.lastUpdate, active: true },
              { label: 'Out for Delivery', date: 'Expected Tomorrow', active: false }
            ].map((step, i) => (
              <div key={i} className="flex gap-6 items-start relative z-10">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 border-white ${step.active ? 'bg-brand-emerald text-white shadow-lg shadow-brand-emerald/30' : 'bg-gray-100 text-gray-300'}`}>
                  <CheckCircle2 size={16} />
                </div>
                <div>
                  <p className={`text-xs font-bold uppercase tracking-widest ${step.active ? 'text-brand-charcoal' : 'text-gray-400'}`}>{step.label}</p>
                  <p className="text-[10px] text-gray-400 mt-1">{step.date}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-6 bg-gray-50 space-y-4">
             <div className="flex items-center gap-4">
               <MapPin size={18} className="text-brand-gold" />
               <p className="text-xs font-bold text-brand-charcoal uppercase tracking-widest">Current: {trackingData.location}</p>
             </div>
             <div className="flex items-center gap-4">
               <Clock size={18} className="text-brand-gold" />
               <p className="text-xs font-bold text-brand-charcoal uppercase tracking-widest">Speed: Next-Day Priority</p>
             </div>
          </div>

          <div className="space-y-4">
             <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Items in this shipment</p>
             {trackingData.items.map((item, i) => (
               <div key={i} className="flex justify-between items-center text-xs p-3 border border-gray-100">
                  <span className="font-bold text-brand-charcoal">{item.name} (x{item.quantity})</span>
                  <span className="text-[9px] bg-white border border-gray-200 px-2 py-1 uppercase">{item.supplier}</span>
               </div>
             ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};
