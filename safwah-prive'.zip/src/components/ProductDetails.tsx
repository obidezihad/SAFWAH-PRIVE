import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Star, ShieldCheck, Truck, ChevronLeft, Heart, Share2, PhoneOutgoing, RefreshCcw, Zap, Sparkles, Clock, Smartphone } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailsProps {
  product: Product;
  isWishlisted: boolean;
  onAddToCart: (p: Product, variant?: any) => void;
  onToggleWishlist: (p: Product) => void;
  onBack: () => void;
}

export const ProductDetails: React.FC<ProductDetailsProps> = ({ product, isWishlisted, onAddToCart, onToggleWishlist, onBack }) => {
  const [selectedSize, setSelectedSize] = useState(product.variants?.sizes?.[0]);
  const [selectedColor, setSelectedColor] = useState(product.variants?.colors?.[0]);
  const [selectedMaterial, setSelectedMaterial] = useState(product.variants?.materials?.[0]);
  const [quantity, setQuantity] = useState(1);
  const [is360View, setIs360View] = useState(false);

  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 3);
  const formattedDelivery = deliveryDate.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });

  return (
    <div className="min-h-screen bg-white pb-32">
      <div className="container mx-auto px-4 pt-8">
        <button onClick={onBack} className="flex items-center gap-2 text-gray-500 hover:text-brand-charcoal mb-8 text-xs font-bold uppercase tracking-widest">
          <ChevronLeft size={16} /> Back to Collection
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Gallery with 360 Toggle */}
          <div className="space-y-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="aspect-[4/5] bg-gray-50 overflow-hidden relative group"
            >
              <img 
                src={product.image} 
                className={`w-full h-full object-cover transition-transform duration-1000 ${is360View ? 'rotate-y-180 scale-110' : ''}`} 
                alt={product.name} 
              />
              
              <button 
                onClick={() => setIs360View(!is360View)}
                className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-white/20 backdrop-blur-md border border-white/30 text-white px-6 py-3 text-[10px] font-bold uppercase tracking-[0.2em] flex items-center gap-2 hover:bg-white hover:text-brand-charcoal transition-all"
              >
                {is360View ? <RefreshCcw size={16} /> : <Zap size={16} />} 
                {is360View ? 'Back to Static' : 'Activate 360° Elite View'}
              </button>

              <div className="absolute top-8 right-8 bg-brand-charcoal/80 backdrop-blur-md px-3 py-1 text-[8px] text-brand-gold font-bold uppercase tracking-widest border border-brand-gold/20 flex items-center gap-2">
                <Sparkles size={10} /> AI Enhanced Capture
              </div>
            </motion.div>
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square bg-gray-100 p-1 cursor-pointer hover:opacity-80 transition-opacity">
                  <img src={product.image} className="w-full h-full object-cover opacity-60" alt="Detail" />
                </div>
              ))}
            </div>
          </div>

          {/* Info */}
          <div className="space-y-8">
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-brand-gold uppercase font-bold tracking-[0.3em]">{product.category}</span>
                  <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                  <span className="text-[9px] text-brand-emerald font-bold uppercase tracking-widest flex items-center gap-1">
                    <ShieldCheck size={12} /> Supplier Verified
                  </span>
                </div>
                <div className="flex gap-4">
                   <button className="text-gray-400 hover:text-brand-emerald"><Share2 size={18}/></button>
                   <button 
                     onClick={() => onToggleWishlist(product)}
                     className={`transition-colors ${isWishlisted ? 'text-brand-emerald' : 'text-gray-400 hover:text-red-500'}`}
                   >
                     <Heart size={18} fill={isWishlisted ? 'currentColor' : 'none'} />
                   </button>
                </div>
              </div>
              <h1 className="text-3xl md:text-5xl font-bold text-brand-charcoal tracking-tight mb-4">{product.name}</h1>
              
              <div className="flex items-center gap-6 mb-8 p-4 bg-gray-50 border-l-4 border-brand-gold">
                <Clock size={20} className="text-brand-gold" />
                <div>
                   <p className="text-[10px] text-brand-charcoal font-bold uppercase tracking-widest">Fast-Sync Delivery</p>
                   <p className="text-xs text-gray-500">Order in next 4h for delivery by <span className="font-bold text-brand-emerald">{formattedDelivery}</span> (Dhaka Priority)</p>
                </div>
              </div>

              <div className="flex items-baseline gap-4">
                <span className="text-4xl font-bold text-brand-emerald italic">৳{product.price}</span>
                {product.originalPrice && (
                  <span className="text-lg text-gray-400 line-through">৳{product.originalPrice}</span>
                )}
                <span className="bg-brand-gold/10 text-brand-gold text-[10px] font-bold px-2 py-1 uppercase tracking-widest">Limited Stock</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-brand-emerald italic">
                <Smartphone size={14} /> AI-Humanized Description
              </div>
              <p className="text-gray-600 leading-relaxed text-sm italic">
                "{product.description}"
              </p>
            </div>

            {/* Variants */}
            <div className="space-y-6">
              {product.variants?.sizes && (
                <div>
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">Select Size</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.sizes.map(size => (
                      <button 
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`w-12 h-12 flex items-center justify-center border font-medium text-xs transition-all ${selectedSize === size ? 'border-brand-emerald bg-brand-emerald text-white' : 'border-gray-200 text-brand-charcoal hover:border-brand-gold'}`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {product.variants?.colors && (
                <div>
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">Select Color</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.colors.map(color => (
                      <button 
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`px-4 h-10 flex items-center justify-center border font-medium text-[10px] uppercase tracking-widest transition-all ${selectedColor === color ? 'border-brand-emerald bg-brand-emerald text-white' : 'border-gray-200 text-brand-charcoal hover:border-brand-gold'}`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {product.variants?.materials && (
                <div>
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">Select Material</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.materials.map(material => (
                      <button 
                        key={material}
                        onClick={() => setSelectedMaterial(material)}
                        className={`px-4 h-10 flex items-center justify-center border font-medium text-[10px] uppercase tracking-widest transition-all ${selectedMaterial === material ? 'border-brand-emerald bg-brand-emerald text-white' : 'border-gray-200 text-brand-charcoal hover:border-brand-gold'}`}
                      >
                        {material}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-8 space-y-4 border-t border-gray-100">
               <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest">
                 <div className="flex items-center gap-2 text-brand-emerald">
                   <ShieldCheck size={18} /> Quality Vetted
                 </div>
                 <div className="flex items-center gap-2 text-brand-gold">
                   <Truck size={18} /> Dhaka Next-Day
                 </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Bar for Mobile/Conversion */}
      <div className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-100 p-4 lg:p-6 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] z-40">
        <div className="container mx-auto max-w-4xl flex items-center gap-4">
          <div className="hidden sm:flex items-center border border-gray-200 h-14">
            <button onClick={() => setQuantity(Math.max(1, quantity-1))} className="px-4 hover:bg-gray-50">-</button>
            <span className="px-4 font-bold">{quantity}</span>
            <button onClick={() => setQuantity(quantity+1)} className="px-4 hover:bg-gray-50">+</button>
          </div>
          <button 
            onClick={() => onAddToCart(product, { size: selectedSize, color: selectedColor, material: selectedMaterial })}
            className="flex-1 bg-brand-charcoal text-white h-14 flex items-center justify-center gap-4 text-xs font-bold uppercase tracking-widest hover:bg-brand-emerald transition-colors"
          >
            <ShoppingBag size={20} className="text-brand-gold" /> Add to Elite Bag
          </button>
          <a 
            href={`https://wa.me/8801700000000?text=${encodeURIComponent(`Hi SAFWAH PRIVE', I would like to order the Elite ${product.name}. \n\nCategory: ${product.category}\nPrice: ৳${product.price}\n\nPlease take my delivery address.`)}`}
            target="_blank"
            rel="noreferrer"
            className="hidden md:flex bg-[#25D366] text-white h-14 px-8 items-center justify-center gap-2 text-xs font-bold uppercase tracking-widest hover:opacity-90 transition-opacity"
          >
            <PhoneOutgoing size={20} /> Order via WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};
