import React, { useState, useEffect } from 'react';
import { ShoppingBag, Star, ShieldCheck, Truck, ArrowRight, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onAddToCart: (p: Product) => void;
  onToggleWishlist: (p: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, isWishlisted, onAddToCart, onToggleWishlist }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative bg-white border border-gray-100 overflow-hidden"
      id={`product-${product.id}`}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-gray-100">
        <img 
          src={product.image} 
          alt={product.name}
          className={`h-full w-full object-cover object-center transition-all duration-700 ${product.secondaryImage ? 'group-hover:opacity-0' : 'group-hover:scale-110'}`}
        />
        {product.secondaryImage && (
          <img 
            src={product.secondaryImage} 
            alt={`${product.name} alternate view`}
            className="absolute inset-0 h-full w-full object-cover object-center transition-all duration-700 opacity-0 group-hover:opacity-100 scale-110 group-hover:scale-100"
          />
        )}
        {product.isTrending && (
          <div className="absolute top-4 left-4 bg-brand-charcoal text-brand-gold border border-brand-gold/30 px-3 py-1 text-[8px] font-bold tracking-[0.2em] uppercase shadow-xl backdrop-blur-md">
            Premium Elite
          </div>
        )}
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-4 right-4 p-2 backdrop-blur-md rounded-full transition-all duration-500 scale-90 group-hover:scale-100 ${isWishlisted ? 'bg-brand-emerald text-white shadow-lg shadow-brand-emerald/20' : 'bg-white/10 text-white border border-white/20 hover:bg-white hover:text-brand-charcoal'}`}
        >
          <Heart size={16} fill={isWishlisted ? 'currentColor' : 'none'} />
        </button>
        
        {/* Quick Buy Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 ease-out">
          <button 
            onClick={() => onAddToCart(product)}
            className="w-full bg-brand-charcoal text-brand-gold border border-brand-gold/20 py-4 px-4 flex items-center justify-center gap-3 text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-brand-gold hover:text-brand-charcoal transition-all shadow-2xl"
          >
            <ShoppingBag size={14} />
            Quick Buy
          </button>
        </div>
      </div>

      <div className="p-6 space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-[9px] text-gray-400 uppercase font-black tracking-[0.3em]">{product.category}</p>
          <div className="flex items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={10} className={i < Math.floor(product.rating) ? 'fill-brand-gold text-brand-gold' : 'text-gray-200'} />
            ))}
          </div>
        </div>
        
        <h3 className="text-brand-charcoal font-bold text-xs uppercase tracking-widest group-hover:text-brand-gold transition-colors truncate">
          {product.name}
        </h3>

        <div className="flex items-baseline gap-3 pt-1">
          <span className="text-brand-charcoal font-black text-base italic">৳{product.price}</span>
          {product.originalPrice && (
            <span className="text-gray-300 line-through text-[10px] font-bold">৳{product.originalPrice}</span>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export const SocialProofPopup: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [data, setData] = useState({ name: 'Zihad', location: 'Dhaka', product: 'Elite Silk Panjabi' });

  useEffect(() => {
    const showInterval = setInterval(() => {
      setVisible(true);
      setTimeout(() => setVisible(false), 5000);
    }, 15000);
    return () => clearInterval(showInterval);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div 
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -100, opacity: 0 }}
          className="fixed bottom-6 left-6 z-50 bg-white shadow-2xl p-4 border-l-4 border-brand-gold flex items-center gap-4 max-w-xs pointer-events-none"
        >
          <div className="h-12 w-12 bg-gray-100 flex-shrink-0">
            <img src="https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?q=80&w=100" alt="Success" className="h-full w-full object-cover" />
          </div>
          <div>
            <p className="text-[10px] text-gray-500 uppercase font-bold tracking-tighter">Recent Purchase</p>
            <p className="text-xs font-medium text-brand-charcoal">
              {data.name} from <span className="font-bold">{data.location}</span> just bought <span className="text-brand-gold">{data.product}</span>
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
