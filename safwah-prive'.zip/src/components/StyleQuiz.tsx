import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Sparkles, CheckCircle2, RefreshCcw, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { MOCK_PRODUCTS } from '../constants';

interface Question {
  id: number;
  text: string;
  options: { text: string; value: string; icon?: string }[];
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    text: "How would you describe your ideal aesthetic?",
    options: [
      { text: "Minimalist Executive", value: "minimalist" },
      { text: "Tech Influencer", value: "tech" },
      { text: "High-Street Fashionista", value: "fashion" },
      { text: "Luxury Homebody", value: "home" }
    ]
  },
  {
    id: 2,
    text: "What's your primary setting?",
    options: [
      { text: "Boardroom & Meetings", value: "work" },
      { text: "Content Studios", value: "social" },
      { text: "Elite Lounges", value: "leisure" },
      { text: "Private Estates", value: "private" }
    ]
  },
  {
    id: 3,
    text: "Select your preferred color palette:",
    options: [
      { text: "Monochrome & Earthy", value: "natural" },
      { text: "Deep Emerald & Gold", value: "royal" },
      { text: "Vibrant Cyan & Neon", value: "vibrant" }
    ]
  }
];

export const StyleQuiz: React.FC<{ onComplete: (bundle: Product[]) => void, onBack: () => void }> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [isFinishing, setIsFinishing] = useState(false);

  const handleAnswer = (value: string) => {
    const newAnswers = [...answers, value];
    setAnswers(newAnswers);
    
    if (currentStep < QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsFinishing(true);
      // Simulate AI analysis
      setTimeout(() => {
        const recommendations = MOCK_PRODUCTS.slice(0, 2); // Mock logic
        onComplete(recommendations);
      }, 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-brand-charcoal flex items-center justify-center p-6">
      <div className="max-w-2xl w-full">
        <AnimatePresence mode="wait">
          {!isFinishing ? (
            <motion.div 
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-12"
            >
              <div className="space-y-2">
                <span className="text-brand-gold text-xs font-bold uppercase tracking-[0.3em]">Step {currentStep + 1} of {QUESTIONS.length}</span>
                <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight leading-tight">
                  {QUESTIONS[currentStep].text}
                </h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {QUESTIONS[currentStep].options.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => handleAnswer(opt.value)}
                    className="p-8 border border-white/10 bg-white/5 hover:bg-brand-gold hover:border-brand-gold hover:text-brand-charcoal transition-all text-left group"
                  >
                    <p className="text-xs font-bold uppercase tracking-widest">{opt.text}</p>
                    <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ArrowRight size={20} />
                    </div>
                  </button>
                ))}
              </div>

              <button onClick={onBack} className="text-white/40 text-[10px] font-bold uppercase tracking-widest hover:text-white transition-colors">
                Cancel Discovery
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="finishing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center space-y-8"
            >
              <div className="relative inline-block">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                  className="w-32 h-32 border-2 border-dashed border-brand-gold rounded-full"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="text-brand-gold" size={40} />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white uppercase tracking-widest">Generating Signature Profile</h3>
                <p className="text-white/50 italic text-sm">Matching your aesthetic with our global supplier catalog...</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
