import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Elite Emerald Silk Panjabi',
    price: 4500,
    originalPrice: 6200,
    image: 'https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?q=80&w=800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1583073030463-2575e2af9f6d?q=80&w=800&auto=format&fit=crop',
    category: 'Fashion',
    description: 'A premium silk Panjabi handcrafted for the modern gentleman of Dhaka.',
    features: ['100% Premium Silk', 'Hand-stitched details', 'Slim fit'],
    inStock: true,
    rating: 4.9,
    reviews: 124,
    isTrending: true,
    variants: {
      sizes: ['M', 'L', 'XL', 'XXL'],
      colors: ['Emerald Green', 'Deep Charcoal', 'Midnight Blue'],
      materials: ['Pure Silk', 'Cotton Blend']
    }
  },
  {
    id: '2',
    name: 'Z-Elite Mesh Smartwatch',
    price: 3200,
    originalPrice: 4500,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1508685096489-775b0af3976d?q=80&w=800&auto=format&fit=crop',
    category: 'Tech',
    description: 'The ultimate tech companion for the busy professional in Chittagong.',
    features: ['Blood Oxygen Monitor', '10-day Battery', 'AMOLED Display'],
    inStock: true,
    rating: 4.8,
    reviews: 89,
    isTrending: true,
    variants: {
      colors: ['Space Grey', 'Rose Gold', 'Matte Black']
    }
  },
  {
    id: '3',
    name: 'Charcoal Minimalist Vase',
    price: 1850,
    image: 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?q=80&w=800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1612196808214-b7e239e5f6b7?q=80&w=800&auto=format&fit=crop',
    category: 'Home Decor',
    description: 'Minimalist charcoal accent piece for premium living spaces.',
    features: ['Handcrafted clay', 'Matte finish', 'Eco-friendly'],
    inStock: true,
    rating: 5.0,
    reviews: 42
  },
  {
    id: '4',
    name: 'Prive Leather Messenger Bag',
    price: 7800,
    originalPrice: 9500,
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=800&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1547949003-9792a18a2601?q=80&w=800&auto=format&fit=crop',
    category: 'Lifestyle',
    description: 'Genuine full-grain leather companion for international travelers.',
    features: ['Genuine Leather', 'Laptop compartment', 'RFID protection'],
    inStock: true,
    rating: 4.7,
    reviews: 67,
    isTrending: true,
    variants: {
      materials: ['Genuine Leather', 'Italian Suede']
    }
  }
];
