import { Product } from '../types';

/**
 * SAFWAH PRIVE' DROPSHIPPING SERVICE
 * ---------------------------------
 * Handles Supplier Data Mapping, Price Calculation, and Stock Syncing.
 */

interface RawSupplierData {
  title: string;
  price_usd: number;
  stock_count: number;
  images: string[];
  options: {
    color?: string[];
    size?: string[];
  };
  supplier_id: string;
}

export const DropshippingService = {
  /**
   * Calculates the "Elite Margin" for Bangladesh Market
   * Rules:
   * 1. Convert USD to BDT (Rate: 120)
   * 2. Add 20% Profit Margin
   * 3. Add Import/Buffer Cost (Flat 200 BDT)
   */
  calculatePrivePrice: (basePriceUsd: number): number => {
    const exchangeRate = 120;
    const baseInBdt = basePriceUsd * exchangeRate;
    const margin = baseInBdt * 0.20;
    const buffer = 200;
    
    // Round to nearest 50 for elite feel (e.g., 2950, 3000)
    return Math.ceil((baseInBdt + margin + buffer) / 50) * 50;
  },

  /**
   * Maps raw data from international suppliers to Safwah Prive' schema.
   * This is where "Pic Import" happens.
   */
  mapToPriveProduct: (raw: RawSupplierData): Partial<Product> => {
    const privePrice = DropshippingService.calculatePrivePrice(raw.price_usd);
    
    return {
      name: raw.title.toUpperCase().split('|')[0].trim(), // Clean Titles
      price: privePrice,
      originalPrice: Math.ceil(privePrice * 1.3 / 100) * 100, // Fake Original for Discount visibility
      image: raw.images[0], // Main product pic
      description: `Part of our curated ${raw.title.split(' ')[0]} collection. Responsibly sourced and quality-vetted.`,
      inStock: raw.stock_count > 0,
      variants: {
        sizes: raw.options.size || [],
        colors: raw.options.color || []
      }
    };
  },

  /**
   * Logic for Supplier Notification Split
   * Triggers when payment is verified in Safwah Admin Dashboard.
   */
  routeOrderToSupplier: async (orderId: string, items: any[]) => {
    const supplierGroups = items.reduce((acc, item) => {
      const sId = item.supplierId || 'default_bd_supplier';
      if (!acc[sId]) acc[sId] = [];
      acc[sId].push(item);
      return acc;
    }, {});

    Object.keys(supplierGroups).forEach(supplierId => {
      console.log(`[ALERT] Notifying Supplier ${supplierId} to fulfill items:`, supplierGroups[supplierId]);
      // Real Implementation: Send Email/Webhook to Supplier Portal
    });
  }
};
