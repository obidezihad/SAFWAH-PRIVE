export interface Product {
  id: string;
  supplierId?: string; // Tracking for Dropshipping
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  secondaryImage?: string;
  category: string;
  subCategory?: string;
  description: string;
  features: string[];
  inStock: boolean;
  rating: number;
  reviews: number;
  isTrending?: boolean;
  variants?: {
    sizes?: string[];
    colors?: string[];
    materials?: string[];
  };
  updatedAt?: string;
}

export type Category = 'Lifestyle' | 'Tech' | 'Fashion' | 'Home Decor' | 'Trending in BD';

export interface CartItem extends Product {
  quantity: number;
  selectedVariant?: {
    size?: string;
    color?: string;
    material?: string;
  };
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  totalAmount: number;
  paymentMethod: 'COD' | 'bKash' | 'Nagad';
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  shippingAddress: {
    fullName: string;
    phone: string;
    address: string;
    city: string;
    district: string;
  };
  createdAt: number;
}
